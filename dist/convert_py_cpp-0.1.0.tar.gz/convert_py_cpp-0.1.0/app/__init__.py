# app/__init__.py

from .converter.src.converter import convert

__all__ = ['convert']
